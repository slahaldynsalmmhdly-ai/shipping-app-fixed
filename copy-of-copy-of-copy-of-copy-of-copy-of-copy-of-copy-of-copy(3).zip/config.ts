// Your web app's Firebase configuration, as provided.
export const firebaseConfig = {
  apiKey: "AIzaSyBA2qIZu6UK1QI9eucfQVlCewC-j-kITjg",
  authDomain: "guaranteed-transfer-b39d2.firebaseapp.com",
  projectId: "guaranteed-transfer-b39d2",
  storageBucket: "guaranteed-transfer-b39d2.firebasestorage.app",
  messagingSenderId: "639304789893",
  appId: "1:639304789893:web:ed3056cec4ed0b81a05eec"
};

// The base URL for your backend API.
export const API_BASE_URL = 'https://shipping-app-backend-fxkl.onrender.com';
